/* eslint-env node */
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
  }
}
